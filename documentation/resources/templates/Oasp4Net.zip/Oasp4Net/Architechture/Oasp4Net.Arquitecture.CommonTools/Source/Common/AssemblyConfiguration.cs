﻿namespace Oasp4Net.Arquitecture.CommonTools.Source.Common
{
    public class ReferencedAssemblyConfiguration
    {
        public char SeparatorChar { get; set; }
        public string ReferencedAssemblies { get; set; }
    }
}
