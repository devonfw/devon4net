﻿namespace Oasp4Net.Arquitecture.CommonTools.Source.Consts
{
    public class AssemblyResolverConsts
    {
        public const string ControllerAssemblies = "ControllerAssemblies";
    }
}
