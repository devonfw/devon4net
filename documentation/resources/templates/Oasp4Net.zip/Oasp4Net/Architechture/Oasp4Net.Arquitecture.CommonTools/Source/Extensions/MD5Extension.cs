﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace Oasp4Net.Arquitecture.CommonTools.Source.Extensions
{
    public static class Md5Extension
    {
        public static string Md5Encode(this string chain)
        {
            // byte array representation of that string
            byte[] encodedPassword = new UTF8Encoding().GetBytes(chain);

            // need MD5 to calculate the hash
            byte[] hash = ((HashAlgorithm)CryptoConfig.CreateFromName("MD5")).ComputeHash(encodedPassword);

            // string representation (similar to UNIX format)
            return BitConverter.ToString(hash)
                // without dashes
                .Replace("-", string.Empty)
                // make lowercase
                .ToLower();
        }
    }
}
