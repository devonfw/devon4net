﻿using System;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace Oasp4Net.Arquitecture.CommonTools.Source.Implementation
{
    public class QueryResolver
    {
        public Expression<Func<TEntity, bool>> ContainsPredicate<TEntity, T>(T[] arr, string fieldname) where TEntity : class
        {
            ParameterExpression entity = Expression.Parameter(typeof(TEntity), "entity");
            MemberExpression member = Expression.Property(entity, fieldname);

            var containsMethods = typeof(Enumerable).GetMethods(BindingFlags.Static | BindingFlags.Public)
            .Where(m => m.Name == "Contains");
            MethodInfo method = null;
            foreach (var m in containsMethods)
            {
                if (m.GetParameters().Count() != 2) continue;
                method = m;
                break;
            }
            method = method.MakeGenericMethod(member.Type);
            var exprContains = Expression.Call(method, new Expression[] { Expression.Constant(arr), member });
            return Expression.Lambda<Func<TEntity, bool>>(exprContains, entity);
        }



        public IQueryable<T> OrderByDynamic<T>( IQueryable<T> query, string sortColumn, bool descending)
        {
            Expression resultExpression = null;
            // Dynamically creates a call like this: query.OrderBy(p => p.SortColumn)
            var parameter = Expression.Parameter(typeof(T), "p");
            var property = typeof(T).GetProperty(sortColumn);
            // this is the part p.SortColumn
            var propertyAccess = Expression.MakeMemberAccess(parameter, property);
            // this is the part p => p.SortColumn
            var orderByExpression = Expression.Lambda(propertyAccess, parameter);

            // finally, call the "OrderBy" / "OrderByDescending" method with the order by lamba expression
            resultExpression = Expression.Call(typeof(Queryable), GetOrderingCommand(descending), new[] { typeof(T), property.PropertyType }, query.Expression, Expression.Quote(orderByExpression));

            return query.Provider.CreateQuery<T>(resultExpression);
        }       



        private string GetOrderingCommand(bool descending)
        {
            return descending ? "OrderByDescending" : "OrderBy"; 
        }
    }
}
