﻿using System.Collections.Generic;
using Oasp4net.DataAccessLayer;
using Oasp4net.DataAccessLayer.Common.Interfaces;

namespace Oasp4Net.Business.Repositories.EntityManagement.Interfaces
{
    //Example
    //public interface IEntityRepository : IRepository<Entity>
    //{
        
    //    List<Entity> GetEntityListFromFilter(bool isFav, decimal maxPrice, int minLikes, string searchBy, List<long> list);
    //}
}