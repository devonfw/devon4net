namespace Oasp4Net.Infrastructure.CrossCutting.Mailing.Implementation
{
    public enum EmailBodyType
    {
        PlainText,
        HtmlText
    }
}