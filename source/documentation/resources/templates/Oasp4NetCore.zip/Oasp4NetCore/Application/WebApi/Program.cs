﻿using System;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;

namespace Oasp4NetCore.WebApiApplication
{
    /// <summary>
    ///     Example http://localhost:2000/api/values
    ///     http://localhost:2000/swagger/v1/swagger.json
    /// </summary>
    public class Program
    {
        private static string AppPath = Directory.GetCurrentDirectory() + @"\Application\WebApi\";
        public static IConfigurationRoot Configuration { get; set; }

        public static void Main(string[] args)
        {
            Configure();
            var host = new WebHostBuilder()
                .UseKestrel()
                .UseContentRoot(Directory.GetCurrentDirectory())
                .UseStartup<Startup>()
                .UseApplicationInsights()
                .UseUrls($"http://*:{Configuration["LocalListenPort"]}")
                .Build();
            Console.WriteLine($"Please read logs at {AppPath}\\Logs\\");
            host.Run();
        }

        public static void Configure()
        {
            var builder = new ConfigurationBuilder().SetBasePath(AppPath)
                .AddJsonFile("appsettings.json");
            Configuration = builder.Build();
        }
    }
}