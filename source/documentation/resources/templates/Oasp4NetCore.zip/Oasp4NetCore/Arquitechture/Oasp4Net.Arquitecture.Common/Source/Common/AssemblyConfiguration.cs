﻿namespace Oasp4NetCore.Architecture.CommonTools.Source.Common
{
    public class ReferencedAssemblyConfiguration
    {
        public char SeparatorChar { get; set; }
        public string ReferencedAssemblies { get; set; }
    }
}