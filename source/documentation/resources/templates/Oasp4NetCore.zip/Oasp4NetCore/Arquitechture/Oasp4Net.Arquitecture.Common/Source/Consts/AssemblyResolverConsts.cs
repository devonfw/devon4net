﻿namespace Oasp4NetCore.Architecture.CommonTools.Source.Consts
{
    public class AssemblyResolverConsts
    {
        public const string ControllerAssemblies = "ControllerAssemblies";
    }
}