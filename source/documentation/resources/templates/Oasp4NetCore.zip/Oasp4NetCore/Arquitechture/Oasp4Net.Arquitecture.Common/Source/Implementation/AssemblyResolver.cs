﻿using System.Reflection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Oasp4NetCore.Architecture.CommonTools.Source.Common;
using Oasp4NetCore.Architecture.CommonTools.Source.Interfaces;

namespace Oasp4NetCore.Architecture.CommonTools.Source.Implementation
{
    public class AssemblyResolver : IAssemblyResolver
    {
        public void GetReferencedAssemblyController(string section, ref IServiceCollection services,
            IConfigurationRoot configuration)
        {
            var config = configuration.GetSection(section).Get<ReferencedAssemblyConfiguration>();
            var assemblies = config.ReferencedAssemblies.Split(config.SeparatorChar);
            foreach (var assemblyName in assemblies)
            {
                if (string.IsNullOrEmpty(assemblyName)) continue;
                var assembly = Assembly.Load(new AssemblyName(assemblyName));
                services.AddMvc().AddApplicationPart(assembly).AddControllersAsServices();
            }
        }
    }
}