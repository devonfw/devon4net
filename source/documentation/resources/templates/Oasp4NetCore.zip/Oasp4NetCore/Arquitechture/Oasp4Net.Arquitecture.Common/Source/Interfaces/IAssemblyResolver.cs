using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Oasp4NetCore.Architecture.CommonTools.Source.Interfaces
{
    public interface IAssemblyResolver
    {
        void GetReferencedAssemblyController(string section, ref IServiceCollection services,
            IConfigurationRoot configuration);
    }
}