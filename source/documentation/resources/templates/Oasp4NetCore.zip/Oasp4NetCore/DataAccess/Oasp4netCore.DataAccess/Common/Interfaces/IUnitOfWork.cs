﻿using System;
using System.Threading.Tasks;

namespace Oasp4net.DataAccess.Common.Interfaces
{

    public interface IUnitOfWork : IDisposable
    {
        int Commit();
        Task<int> CommitAsync();
    }
}
